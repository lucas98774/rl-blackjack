# README

![Build Package and Test Game](https://github.com/lucas98774/rl-blackjack/actions/workflows/build-test.yml/badge.svg)

This project is to start learning about reinforcement learning. The starting task will be to solve the gamblers dilema with the blackjack game.

## Implementation

At first everything will be looked to implement from scratch and then a solution using built in packages (gym) will be used.

## Evironment:
Python Version: 3.8.12
Pip version: 21.2.2

## NOTE

This branch is essentially just a backup that does not have protection rules --- easier to automate checks and formatting.
 